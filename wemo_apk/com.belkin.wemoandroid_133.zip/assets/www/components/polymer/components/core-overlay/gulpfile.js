var gulp = require('gulp');
require('gulp-web-component-tester').init(gulp);
