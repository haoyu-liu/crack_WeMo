package android.net.http;

class Request
{
  Request()
  {
    throw new RuntimeException("Stub!");
  }
  
  public void handleSslErrorResponse(boolean paramBoolean)
  {
    throw new RuntimeException("Stub!");
  }
  
  public String toString()
  {
    throw new RuntimeException("Stub!");
  }
}


/* Location:              /root/Documents/wemo_apk/classes-dex2jar.jar!/android/net/http/Request.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */