package android.net.compatibility;

public class WebAddress
{
  public WebAddress(String paramString)
    throws IllegalArgumentException
  {
    throw new RuntimeException("Stub!");
  }
  
  public String getAuthInfo()
  {
    throw new RuntimeException("Stub!");
  }
  
  public String getHost()
  {
    throw new RuntimeException("Stub!");
  }
  
  public String getPath()
  {
    throw new RuntimeException("Stub!");
  }
  
  public int getPort()
  {
    throw new RuntimeException("Stub!");
  }
  
  public String getScheme()
  {
    throw new RuntimeException("Stub!");
  }
  
  public void setAuthInfo(String paramString)
  {
    throw new RuntimeException("Stub!");
  }
  
  public void setHost(String paramString)
  {
    throw new RuntimeException("Stub!");
  }
  
  public void setPath(String paramString)
  {
    throw new RuntimeException("Stub!");
  }
  
  public void setPort(int paramInt)
  {
    throw new RuntimeException("Stub!");
  }
  
  public void setScheme(String paramString)
  {
    throw new RuntimeException("Stub!");
  }
  
  public String toString()
  {
    throw new RuntimeException("Stub!");
  }
}


/* Location:              /root/Documents/wemo_apk/classes-dex2jar.jar!/android/net/compatibility/WebAddress.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */