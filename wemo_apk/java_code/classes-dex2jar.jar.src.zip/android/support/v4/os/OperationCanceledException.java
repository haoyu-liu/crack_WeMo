package android.support.v4.os;

public class OperationCanceledException
  extends RuntimeException
{
  public OperationCanceledException()
  {
    this(null);
  }
  
  public OperationCanceledException(String paramString) {}
}


/* Location:              /root/Documents/wemo_apk/classes-dex2jar.jar!/android/support/v4/os/OperationCanceledException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */