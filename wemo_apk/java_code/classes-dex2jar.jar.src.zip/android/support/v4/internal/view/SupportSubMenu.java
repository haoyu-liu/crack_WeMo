package android.support.v4.internal.view;

import android.view.SubMenu;

public abstract interface SupportSubMenu
  extends SupportMenu, SubMenu
{}


/* Location:              /root/Documents/wemo_apk/classes-dex2jar.jar!/android/support/v4/internal/view/SupportSubMenu.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */