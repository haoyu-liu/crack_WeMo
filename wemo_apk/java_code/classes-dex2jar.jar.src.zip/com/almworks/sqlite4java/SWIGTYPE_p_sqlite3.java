package com.almworks.sqlite4java;

class SWIGTYPE_p_sqlite3
{
  private long swigCPtr;
  
  protected SWIGTYPE_p_sqlite3()
  {
    this.swigCPtr = 0L;
  }
  
  protected SWIGTYPE_p_sqlite3(long paramLong, boolean paramBoolean)
  {
    this.swigCPtr = paramLong;
  }
  
  protected static long getCPtr(SWIGTYPE_p_sqlite3 paramSWIGTYPE_p_sqlite3)
  {
    if (paramSWIGTYPE_p_sqlite3 == null) {
      return 0L;
    }
    return paramSWIGTYPE_p_sqlite3.swigCPtr;
  }
}


/* Location:              /root/Documents/wemo_apk/classes-dex2jar.jar!/com/almworks/sqlite4java/SWIGTYPE_p_sqlite3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */