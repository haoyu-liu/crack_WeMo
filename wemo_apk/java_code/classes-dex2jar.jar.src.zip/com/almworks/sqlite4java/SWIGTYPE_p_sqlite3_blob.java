package com.almworks.sqlite4java;

class SWIGTYPE_p_sqlite3_blob
{
  private long swigCPtr;
  
  protected SWIGTYPE_p_sqlite3_blob()
  {
    this.swigCPtr = 0L;
  }
  
  protected SWIGTYPE_p_sqlite3_blob(long paramLong, boolean paramBoolean)
  {
    this.swigCPtr = paramLong;
  }
  
  protected static long getCPtr(SWIGTYPE_p_sqlite3_blob paramSWIGTYPE_p_sqlite3_blob)
  {
    if (paramSWIGTYPE_p_sqlite3_blob == null) {
      return 0L;
    }
    return paramSWIGTYPE_p_sqlite3_blob.swigCPtr;
  }
}


/* Location:              /root/Documents/wemo_apk/classes-dex2jar.jar!/com/almworks/sqlite4java/SWIGTYPE_p_sqlite3_blob.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */