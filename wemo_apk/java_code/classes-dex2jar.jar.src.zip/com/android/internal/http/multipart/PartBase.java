package com.android.internal.http.multipart;

public abstract class PartBase
  extends Part
{
  public PartBase(String paramString1, String paramString2, String paramString3, String paramString4)
  {
    throw new RuntimeException("Stub!");
  }
  
  public String getCharSet()
  {
    throw new RuntimeException("Stub!");
  }
  
  public String getContentType()
  {
    throw new RuntimeException("Stub!");
  }
  
  public String getName()
  {
    throw new RuntimeException("Stub!");
  }
  
  public String getTransferEncoding()
  {
    throw new RuntimeException("Stub!");
  }
  
  public void setCharSet(String paramString)
  {
    throw new RuntimeException("Stub!");
  }
  
  public void setContentType(String paramString)
  {
    throw new RuntimeException("Stub!");
  }
  
  public void setName(String paramString)
  {
    throw new RuntimeException("Stub!");
  }
  
  public void setTransferEncoding(String paramString)
  {
    throw new RuntimeException("Stub!");
  }
}


/* Location:              /root/Documents/wemo_apk/classes-dex2jar.jar!/com/android/internal/http/multipart/PartBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */