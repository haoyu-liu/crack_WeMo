package com.android.internal.http.multipart;

import java.io.InputStream;

public class ByteArrayPartSource
  implements PartSource
{
  public ByteArrayPartSource(String paramString, byte[] paramArrayOfByte)
  {
    throw new RuntimeException("Stub!");
  }
  
  public InputStream createInputStream()
  {
    throw new RuntimeException("Stub!");
  }
  
  public String getFileName()
  {
    throw new RuntimeException("Stub!");
  }
  
  public long getLength()
  {
    throw new RuntimeException("Stub!");
  }
}


/* Location:              /root/Documents/wemo_apk/classes-dex2jar.jar!/com/android/internal/http/multipart/ByteArrayPartSource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */